package com.cg.rms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.rms.beans.CandidatePersonal;

import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CompanyService;
import com.cg.rms.service.CompanyServiceImpl;


public class CompanyUIImpl implements CompanyUI{
    static CompanyService companyService=new CompanyServiceImpl() ;
    LoginUI login=new LoginUIImpl();
    
    @Override
    public void regCompDetails(String id) {
        Scanner sc=new Scanner(System.in);
        String companyName;
        String companyAddress;
        String contactPerson;
        String emailId;
        String contactNumber;
        try {
            System.out.println("---------Register your company here---------");
            System.out.println("Enter company name");
            companyName =sc.next();
            System.out.println("Enter company address");
            companyAddress =sc.next();
            System.out.println("Enter  contact person");
            contactPerson=sc.next();
            System.out.println("Enter  company email-id");
            emailId=sc.next();
            System.out.println("Enter  contact number");
            contactNumber=sc.next();
            CompanyMaster com=new CompanyMaster(id,companyName,companyAddress,contactPerson,emailId,contactNumber);
            
           String companyId= companyService.registerCompany(com);
            

            System.out.println("======================================================");
            System.out.println("Successfully registered....Your Company ID is"+companyId);
            System.out.println();
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Override
    public void postJobReq(String id) {
        Scanner sc=new Scanner(System.in);
        String jobId ;
        String companyId;
        String positionRequired;
        int numbersRequired;
        int experienceRequired;
        String qualificationRequired;
        String jobLocation;
        String jobDescription;
       
        try {
        	 
            System.out.println("--------Post jobs here---------");
            ArrayList<CompanyMaster> companyList=companyService.getCompanyDetails();
            System.out.println("Company ID   Company Name");
            System.out.println("--------------------------");
            for(CompanyMaster clist:companyList)
            {
            	System.out.println(clist.getCompanyId()+"          "+clist.getCompanyName());
            }
            System.out.println("Enter Company Id for which you want to post jobs");
            companyId=sc.next();
            System.out.println("Enter position required");
            positionRequired =sc.next();
            System.out.println("Enter no. of vacancies");
            numbersRequired=sc.nextInt();
            System.out.println("Enter experience required");
            experienceRequired=sc.nextInt();
            System.out.println("Enter qualification required");
            qualificationRequired=sc.next();
            System.out.println("Enter job location");
            jobLocation=sc.next();
            System.out.println("Enter job description");
            jobDescription=sc.next();
            JobRequirements jobreq=new JobRequirements(companyId,positionRequired,numbersRequired,experienceRequired,qualificationRequired,jobLocation,jobDescription);


            String s=companyService.postJobRequirement(jobreq);

            System.out.println("Successfully  Job requirements are added for Job Id...."+s);
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    @Override
    public void searchCandidate() {
        Scanner sc=new Scanner(System.in);
        ArrayList<CandidatePersonal> cList=null;
        int experienceRequired;
        String qualificationRequired;
        String positionRequired;
        try {
            System.out.println("Enter experience required");
            experienceRequired=sc.nextInt();
            System.out.println("Enter qualification required");
            qualificationRequired=sc.next();
            System.out.println("Enter position required");
            positionRequired =sc.next();
            cList=companyService.SearchByCompany(positionRequired, experienceRequired, qualificationRequired);
            if(cList.isEmpty()==true)
            {
                System.out.println("No candidate found as per the given criteria....");
                System.out.println("----------------------------------------------------");

            }
            else
            {
                System.out.println("=============================================================================================");
                System.out.println("\t CandidateId  \t candidateName  \t emailId \t contactNumber \t gender ");
                System.out.println("=============================================================================================");
                for(CandidatePersonal cc:cList)
                {
                    System.out.println("\t"+cc.getCandidateId()+"\t"+cc.getCandidateName()+"\t"+cc.getEmailId()+"\t"+cc.getContactNumber()+"\t"+cc.getGender());
                }
               
            }
        }
        catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Override
    public void showCompanyMenu(String id)
    {

        System.out.println("1.Register Compnay Details\n"
                + "2.PostJobRequirements\n"
                + "3.Search Candidate based on Experience Required,"
                + "Qualification required,Position Required\n"
                + "4.Logout");
        Scanner sc=new Scanner(System.in);
        int choice=0;
        choice=sc.nextInt();
        switch(choice)
        {
        case 1:regCompDetails(id);break;
        case 2:postJobReq(id);break;
        case 3:searchCandidate();break;
        case 4:System.out.println("Successfully sign out");login.showMenu(); break;
        default:System.out.println("Invalid input");
        }
        showCompanyMenu(id);
    }
}